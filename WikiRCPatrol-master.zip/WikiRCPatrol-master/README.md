# RC patrol
Lightweight RC patrol script for Wikipedia and other MediaWiki wikis (no extensions or configuration required for the end user).

The goal of this is to have a lightweight, cross-wiki RC patrol script that works on many MediaWiki wikis out of the box.  The script should be powerful and customizable to any wiki, with features that can be enabled/disabled or reconfigured for any particular wiki.

## Contributing
At the moment, the way you can contribute is through pull/merge requests.